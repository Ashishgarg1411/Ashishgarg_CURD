const router = require('express').Router()
const Empdb = require('../model/empdb')

router.get('/',(req,res)=>{
    res.render('employeeadd.ejs')
})

router.post('/empadd',async(req,res)=>{
    const{name,email,phone,address,city,zip,doe,dob} = req.body
    const record = new Empdb({name:name,email:email,phone:phone,address:address,city:city,zip:zip,doe:doe,dob:dob})
    await record.save()
    res.redirect('/empfetch')
})
router.get('/empfetch',async(req,res)=>{
    const record = await Empdb.find()
    res.render('employeefetch.ejs',{record})
})

router.get('/empupdate/:id',async(req,res)=>{
    const id = req.params.id
    const record = await Empdb.findById(id)
    res.render('employeeupdate.ejs',{record})
})

router.post('/empupdateid/:id',async(req,res)=>{
    const{name,email,phone,address,city,zip,doe,dob} = req.body
    const id = req.params.id
    await Empdb.findByIdAndUpdate(id,{name:name,email:email,phone:phone,address:address,city:city,zip:zip,doe:doe,dob:dob})
    res.redirect('/empfetch')
})

router.get('/empdelete/:id',async(req,res)=>{
    const id = req.params.id
    await Empdb.findByIdAndDelete(id)
    res.redirect('/empfetch')
})

router.get('/details/:id',async(req,res)=>{
    const id = req.params.id
    const record = await Empdb.findById(id)
    res.render('details.ejs',{record})
})
module.exports = router