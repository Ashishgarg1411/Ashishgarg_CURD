const mongoose = require('mongoose')

const empSchema = mongoose.Schema({
    name:String,
    email:String,
    phone:String,
    address:String,
    city:String,
    zip:String,
    doe:String,
    dob:String
})

module.exports = mongoose.model('emp',empSchema)