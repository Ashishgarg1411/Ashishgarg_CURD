import { useNavigate, useParams } from "react-router-dom";

function EmpDelete() {
    const{id} = useParams()
    const navigate = useNavigate()

    fetch(`/api/singleempdelete/${id}`,{
        method:'DELETE'
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==="Successfully Delete"){
            navigate('/employeedata')
        }
    })


    return ( 
        <h2>Employee delete{id}</h2>
     );
}

export default EmpDelete;