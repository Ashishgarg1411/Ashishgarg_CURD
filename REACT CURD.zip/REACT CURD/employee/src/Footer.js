function Footer() {
    return ( 
        
        <section id="footer">
        <h4>REACT CURD</h4>
        </section>
     );
}

export default Footer;