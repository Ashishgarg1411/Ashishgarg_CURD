const { createContext } = require("react");

export const LoginContext =  createContext(null)