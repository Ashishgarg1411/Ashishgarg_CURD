const mongoose = require('mongoose')

const reactSchema = mongoose.Schema({
    name:String,
    email:String,
    phone:Number,
    address:String,
    city:String,
    zip_code:Number,
    Date_of_employment:String,
    date_of_birth:String
    })

module.exports = mongoose.model('reactdb',reactSchema)