const router = require('express').Router()
const Addemp = require('../models/reactdb')


router.post('/insert', async (req, res) => {
   const { name, email, phone, address, city, zip, doe, dob } = req.body
   const record = new Addemp({ name: name, email: email, phone: phone, address: address, city: city, zip_code: zip, Date_of_employment: doe, date_of_birth: dob })
   await record.save()
   res.json(record)
})

router.get('/showempdata', async (req, res) => {
   const record = await Addemp.find()
   res.json(record)
})

router.get('/singhfetchempployee/:id', async (req, res) => {
   const id = req.params.id
   const record = await Addemp.findById(id)
   res.json(record)
})
router.put('/singleempupdate/:id', async (req, res) => {
   const { name, email, phone, address, city, zip, doe, dob } = req.body
   const id = req.params.id
   await Addemp.findByIdAndUpdate(id, { name: name, email: email, phone: phone, address: address, city: city, zip_code: zip, Date_of_employment: doe, date_of_birth: dob })
   res.json({ message: "successfully updated" })
})

router.delete('/singleempdelete/:id', async (req, res) => {
   const id = req.params.id
   await Addemp.findByIdAndDelete(id)
   res.json({ message: "Successfully Delete" })
})



module.exports = router